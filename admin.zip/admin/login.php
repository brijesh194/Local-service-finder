<?php
require_once __DIR__ . '/../helpers.php';
session_start();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $u = $_POST['user'] ?? ''; $p = $_POST['pass'] ?? '';
  if ($u===ADMIN_USER && $p===ADMIN_PASS) { $_SESSION['admin_logged']=true; header('Location: '.url('admin/dashboard.php')); exit; }
  $err = 'Invalid credentials';
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Admin Login</title>
<style>body{background:#0f1115;color:#e6f1ff;font-family:Inter,Arial} .wrap{max-width:420px;margin:80px auto;background:#121722;border:1px solid #1e2633;padding:20px;border-radius:16px}
input{width:100%;padding:12px;border-radius:10px;border:1px solid #243043;background:#0f131b;color:#dbeafe;margin:8px 0}
.btn{background:#22ccff;border:none;padding:12px 16px;border-radius:12px;font-weight:700;cursor:pointer}</style></head>
<body><div class="wrap"><h2>Admin Login</h2>
<?php if(!empty($err)) echo "<p style='color:#ef4444'>$err</p>"; ?>
<form method="post"><input name="user" placeholder="Username" required><input type="password" name="pass" placeholder="Password" required><button class="btn">Login</button></form>
</div></body></html>

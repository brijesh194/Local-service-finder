<?php require_once __DIR__ . '/db.php'; require_once __DIR__ . '/helpers.php'; ?>
<?php
// Fetch only APPROVED providers for homepage
// $stmt = db()->prepare("SELECT * FROM providers WHERE status='approved' ORDER BY created_at DESC");
$stmt = db()->prepare("SELECT * FROM providers ORDER BY created_at DESC");

$stmt->execute();
$providers = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title><?= SITE_NAME ?> — Find Trusted Local Services</title>
<style>
/* ======= Premium Dark Theme & Animations ======= */
:root{
  --bg:#0f1115; --card:#141821; --muted:#9aa4b2; --pri:#22ccff; --pri-2:#1aa3cc; --accent:#8b5cf6; --ok:#22c55e; --danger:#ef4444; --glow:0 0 0 transparent;
}
*{box-sizing:border-box}
body{margin:0;font-family:Inter,system-ui,Arial, sans-serif;background:var(--bg);color:#fff;}
a{color:inherit;text-decoration:none}
.btn{background:var(--pri);border:none;padding:12px 16px;border-radius:12px;font-weight:600;cursor:pointer;transition:.25s}
.btn:hover{background:var(--pri-2);box-shadow:0 8px 24px rgba(34,204,255,.25)}
.badge{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;border-radius:999px;font-size:12px;background:#1f2632;color:#cfefff}
.wrap{max-width:1200px;margin:0 auto;padding:0 20px}

/* Navbar */
.nav{position:sticky;top:0;z-index:30;background:linear-gradient(180deg,#0f1115 0%, rgba(15,17,21,.85) 100%);backdrop-filter: blur(8px);border-bottom:1px solid #1d2330}
.nav-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
.logo{font-weight:900;letter-spacing:.4px;color:#a5f3fc}
.nav-links{display:flex;gap:18px}
.nav-links a{color:#dbeafe;opacity:.85}
.nav-links a:hover{opacity:1}

/* Hero */
.hero{padding:64px 0 28px;background:
radial-gradient(800px 400px at 20% -10%, rgba(34,204,255,.12), transparent 70%),
radial-gradient(800px 400px at 80% 0%, rgba(139,92,246,.12), transparent 70%);
}
.hero h1{font-size:40px;line-height:1.15;margin:10px 0 8px}
.hero p{color:var(--muted);max-width:720px}
.hero-row{display:grid;grid-template-columns:1.1fr .9fr;gap:24px;align-items:center}
.hero-card{background:linear-gradient(180deg,#141821,#12151d);border:1px solid #1e2633;border-radius:18px;padding:18px;box-shadow:0 8px 40px rgba(0,0,0,.35); padding-bottom: 50px;}
.searchbox{display:flex;gap:10px;margin-top:10px}
.searchbox input, .searchbox select{flex:1;padding:12px;border-radius:12px;border:1px solid #243043;background:#0f131b;color:#e5f2ff}
.searchbox .btn{padding:12px 16px}

/* Counters / trust strip */
.trust{display:flex;gap:14px;margin-top:18px;flex-wrap:wrap}
.kpi{background:#121722;border:1px solid #1e2633;border-radius:14px;padding:10px 14px;color:#c7d2fe}
.kpi strong{display:block;font-size:20px;color:#e0f2fe}
.kpi small{color:#94a3b8}

/* Sticky filter bar (chips, sort, view) */
.stickybar{position:sticky;top:64px;z-index:20;background:#0f1115;border-top:1px solid #1d2330;border-bottom:1px solid #1d2330}
.stickybar-inner{display:flex;align-items:center;justify-content:space-between;padding:12px 0;gap:12px}
.chips{display:flex;gap:8px;flex-wrap:wrap}
.chip{border:1px solid #263244;background:#121722;color:#c7d2fe;padding:8px 12px;border-radius:999px;cursor:pointer;transition:.25s}
.chip.active, .chip:hover{border-color:#2f9ad1;background:#0f172a;color:#e2f6ff;box-shadow:0 8px 24px rgba(34,204,255,.15)}
.sortview{display:flex;gap:10px;align-items:center}
.select{padding:10px;border-radius:12px;border:1px solid #243043;background:#0f131b;color:#cfefff}
.toggle{display:flex;border:1px solid #243043;border-radius:12px;overflow:hidden}
.toggle button{background:#0f131b;border:0;padding:10px 12px;color:#cfefff}
.toggle button.active{background:#172032}

/* Layout: sidebar + results */
.layout{display:grid;grid-template-columns:280px 1fr;gap:20px;margin-top:20px}
.sidebar{position:sticky;top:112px;align-self:start;background:#121722;border:1px solid #1e2633;border-radius:16px;padding:16px}
.side h4{margin:8px 0 12px}
.range, .check, .tagbox, .avail{margin-bottom:16px}
.range input[type=range]{width:100%}
.list{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.list.list-view{grid-template-columns:1fr}

/* Provider Card (HTML-editable) */
.card{position:relative;background:linear-gradient(180deg,#141821,#0f1115);border:1px solid #1e2633;border-radius:16px;padding:14px;transition:.25s;overflow:hidden}
.card:hover{transform:translateY(-4px);box-shadow:0 18px 60px rgba(34,204,255,.12), 0 2px 0 rgba(139,92,246,.2)}
.card .thumb{height:160px;border-radius:12px;overflow:hidden;margin-bottom:10px}
.card .thumb img{width:100%;height:100%;object-fit:cover;display:block;transition:scale .35s}
.card:hover .thumb img{scale:1.05}
.card .title{display:flex;align-items:center;gap:8px;margin:6px 0}
.tick{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:999px;background:#0ea5e9}
.tick svg{width:14px;height:14px}
.meta{display:flex;gap:10px;color:#a5b4fc;font-size:13px;flex-wrap:wrap}
.desc{color:#9aa4b2;font-size:14px;margin:6px 0 10px; padding-bottom: 50px;}
.cta{display:flex;gap:10px}
.ghost{background:transparent;border:1px solid #2a3b52;padding:10px 12px;border-radius:10px;color:#dbeafe}
.price{position:absolute;top:12px;right:12px;background:#0b1220;border:1px solid #203049;color:#cfefff;padding:6px 10px;border-radius:12px;font-weight:700}
.rating{position:absolute;top:12px;left:12px;background:#0b1220;border:1px solid #203049;color:#ffe58a;padding:6px 10px;border-radius:12px;font-weight:700}

/* Load more + empty */
.loadmore{display:flex;justify-content:center;margin:18px 0}
.empty{padding:32px;text-align:center;color:#94a3b8;border:1px dashed #263244;border-radius:16px}

/* Footer */
.footer{margin-top:36px;padding:20px 0;border-top:1px solid #1d2330;color:#9aa4b2}
.footer .row{display:flex;gap:20px;flex-wrap:wrap;justify-content:space-between}
.footer a{color:#cfefff;opacity:.8}
.footer a:hover{opacity:1}
</style>
</head>
<body>

<!-- ======= NAVBAR ======= -->
<header class="nav">
  <div class="wrap nav-inner">
    <div class="logo"><?= SITE_NAME ?></div>
    <nav class="nav-links">
      <a href="<?= url('index.php') ?>">Home</a>
      <a href="#categories">Categories</a>
      <a href="#results">Providers</a>
      <a href="create-profile.php" class="btn" style="padding:8px 14px">Create Profile</a>

    </nav>
  </div>
</header>

<!-- ======= HERO (Category + Quick Search) ======= -->
<section class="hero">
  <div class="wrap hero-row">
    <div class="hero-card">
      <h1>Find trusted local pros near you.</h1>
      <p>Verified providers, transparent pricing, real ratings. Book with confidence.</p>
      <div class="searchbox">
        <select id="qCategory">
          <option value="">All Categories</option>
          <option>Plumber</option><option>Electrician</option><option>Carpenter</option>
          <option>Salon</option><option>Cleaning</option><option>Tutor</option>
          <option>Painter</option><option>AC Repair</option><option>Electronics</option>
        </select>
        <input id="qText" type="text" placeholder="Search by name, tag, location..." />
        <button class="btn" id="qBtn">Search</button>
      </div>
      <div class="trust">
        <div class="kpi"><strong id="kpiProviders"><?= count($providers) ?></strong><small>Verified Providers</small></div>
        <div class="kpi"><strong>4.7★</strong><small>Avg Rating</small></div>
        <div class="kpi"><strong>10K+</strong><small>Bookings</small></div>
      </div>
    </div>
    <div class="hero-card">
      <span class="badge">✅ Safety & Verification</span>
      <h3 style="margin:10px 0">Every profile is reviewed by admin with ID proof.</h3>
      <p class="desc">Your safety matters. We approve only genuine providers—with a blue tick when verified.</p>
      <a class="btn" href="create-profile.php">Become a Provider</a>
    </div>
  </div>
</section>

<!-- ======= STICKY FILTER BAR ======= -->
<div class="stickybar">
  <div class="wrap stickybar-inner">
    <div class="chips" id="chips">
      <div class="chip" data-chip="verified">Verified</div>
      <div class="chip" data-chip="today">Available Today</div>
      <div class="chip" data-chip="under500">Under ₹500</div>
      <div class="chip" data-chip="rating4">Rating 4+</div>
    </div>
    <div class="sortview">
      <select id="sort" class="select">
        <option value="">Sort</option>
        <option value="priceAsc">Price: Low → High</option>
        <option value="priceDesc">Price: High → Low</option>
        <option value="ratingDesc">Rating: High → Low</option>
      </select>
      <div class="toggle">
        <button id="gridBtn" class="active">Grid</button>
        <button id="listBtn">List</button>
      </div>
    </div>
  </div>
</div>

<!-- ======= LAYOUT: SIDEBAR + RESULTS ======= -->
<main class="wrap layout" id="results">
  <!-- Sidebar Filters -->
  <aside class="sidebar side">
    <div class="range">
      <h4>Price Range (₹)</h4>
      <input type="range" min="100" max="5000" step="50" value="2500" id="priceRange"/>
      <div style="display:flex;justify-content:space-between;color:#9aa4b2"><small>100</small><small id="priceVal">2500</small></div>
    </div>
    <div class="range">
      <h4>Minimum Rating</h4>
      <input type="range" min="1" max="5" step="0.1" value="3.5" id="ratingRange"/>
      <div style="display:flex;justify-content:space-between;color:#9aa4b2"><small>1.0</small><small id="ratingVal">3.5</small></div>
    </div>
    <div class="check">
      <h4>Verified</h4>
      <label style="display:flex;gap:8px;align-items:center;color:#cfefff">
        <input type="checkbox" id="verifiedOnly"/> Show only verified
      </label>
    </div>
    <div class="tagbox">
      <h4>Tags</h4>
      <input id="tagInput" placeholder="e.g., kitchen, wiring, haircut" style="width:100%;padding:10px;border-radius:10px;border:1px solid #243043;background:#0f131b;color:#cfefff" />
      <small style="color:#9aa4b2">comma separated</small>
    </div>
    <div class="avail">
      <h4>Availability</h4>
      <select id="availability" class="select" style="width:100%">
        <option value="">Any</option>
        <option>Today</option>
        <option>Tomorrow</option>
        <option>This Week</option>
        <option>Weekends</option>
      </select>
    </div>
  </aside>

  <!-- Results Area -->
  <section>
    <div class="list" id="cards">
      <!-- Provider cards rendered below (editable HTML, with data-attributes for JS) -->
      <?php if (empty($providers)): ?>
        <div class="empty">No verified providers yet. Be the first — <a class="btn" style="margin-left:8px" href="<?= url('create-profile.php') ?>">Create Profile</a></div>
      <?php else: foreach ($providers as $p): ?>
        <article class="card" 
          data-price="<?= (int)$p['price'] ?>"
          data-rating="<?= (float)$p['rating'] ?>"
          data-verified="<?= (int)$p['verified'] ?>"
          data-tags="<?= sanitize($p['tags']) ?>"
          data-availability="<?= sanitize($p['availability']) ?>"
          data-category="<?= sanitize($p['service']) ?>"
          data-name="<?= sanitize($p['name']) ?>"
          data-location="<?= sanitize($p['location']) ?>">
          <div class="rating"><?= number_format((float)$p['rating'],1) ?>★</div>
          <div class="price">From ₹<?= (int)$p['price'] ?></div>
          <div class="thumb"><img src="/<?= htmlspecialchars($p['photo_path']) ?>" alt="<?= htmlspecialchars($p['name']) ?>"></div>
          <div class="title">
            <h3 style="margin:0"><?= sanitize($p['name']) ?></h3>
            <?php if ($p['verified']): ?>
              <span class="tick" title="Verified">
                <svg viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke="#e6faff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </span>
            <?php endif; ?>
          </div>
          <div class="meta">
            <span><?= sanitize($p['service']) ?></span> • 
            <span><?= sanitize($p['location']) ?></span> •
            <span><?= (int)$p['experience_years'] ?> yrs exp</span>
          </div>
          <p class="desc"><?= sanitize($p['short_desc']) ?></p>
          <div class="cta">
            <a class="ghost" href="provider.php?id=<?= $p['id'] ?>">View Details</a>
            <a class="btn" href="provider.php?id=<?= $p['id'] ?>#book">Book / Contact</a>
          </div>
        </article>
      <?php endforeach; endif; ?>
    </div>

    <!-- Load more -->
    <div class="loadmore"><button class="btn" id="loadMoreBtn">Load More</button></div>
  </section>
</main>

<!-- ======= FOOTER ======= -->
<footer class="footer">
  <div class="wrap row">
    <div>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</div>
    <div style="display:flex;gap:16px">
      <a href="#">Privacy</a><a href="#">Terms</a><a href="<?= url('create-profile.php') ?>">Become a Provider</a>
    </div>
  </div>
</footer>

<script>
// ======= Frontend JS: Filters, Sort, View Toggle, Load More =======

// Helper: read all cards into array
const cardsWrap = document.getElementById('cards');
const allCards = Array.from(cardsWrap.querySelectorAll('.card'));

// State
let currentView = 'grid';         // or 'list'
let visibleCount = 6;             // initial items to show
const step = 6;

// DOM refs
const gridBtn = document.getElementById('gridBtn');
const listBtn = document.getElementById('listBtn');
const sortSel = document.getElementById('sort');
const loadMoreBtn = document.getElementById('loadMoreBtn');
const priceRange = document.getElementById('priceRange');
const ratingRange = document.getElementById('ratingRange');
const verifiedOnly = document.getElementById('verifiedOnly');
const tagInput = document.getElementById('tagInput');
const availabilitySel = document.getElementById('availability');
const priceVal = document.getElementById('priceVal');
const ratingVal = document.getElementById('ratingVal');
const chips = document.getElementById('chips');
const qCategory = document.getElementById('qCategory');
const qText = document.getElementById('qText');
const qBtn = document.getElementById('qBtn');

// Display helper
function updateViewToggle(){
  if(currentView==='grid'){ cardsWrap.classList.remove('list-view'); gridBtn.classList.add('active'); listBtn.classList.remove('active'); }
  else { cardsWrap.classList.add('list-view'); listBtn.classList.add('active'); gridBtn.classList.remove('active'); }
}
gridBtn.onclick = ()=>{currentView='grid'; updateViewToggle();}
listBtn.onclick = ()=>{currentView='list'; updateViewToggle();}
updateViewToggle();

// Load more logic
function applyVisibility(filtered){
  allCards.forEach(c=>c.style.display='none');
  filtered.slice(0, visibleCount).forEach(c=>c.style.display='block');
  loadMoreBtn.style.display = filtered.length > visibleCount ? 'inline-flex' : 'none';
}
loadMoreBtn.onclick = ()=>{ visibleCount += step; filterAll(); };

// Core filter
function filterAll(){
  // read controls
  const maxPrice = +priceRange.value;
  const minRating = +ratingRange.value;
  const vOnly = verifiedOnly.checked;
  const tags = tagInput.value.toLowerCase().split(',').map(s=>s.trim()).filter(Boolean);
  const avail = availabilitySel.value;
  const qCat = qCategory.value;
  const query = qText.value.toLowerCase().trim();

  // chip quick filters
  const chipActive = (key)=> !!chips.querySelector(`.chip[data-chip="${key}"].active`);
  const chipVerified = chipActive('verified');
  const chipToday = chipActive('today');
  const chipUnder500 = chipActive('under500');
  const chipRating4 = chipActive('rating4');

  // filter
  let filtered = allCards.filter(card=>{
    const price = +card.dataset.price;
    const rating = +card.dataset.rating;
    const verified = +card.dataset.verified===1;
    const cardTags = (card.dataset.tags||'').toLowerCase();
    const cardAvail = (card.dataset.availability||'').toLowerCase();
    const category = (card.dataset.category||'').toLowerCase();
    const name = (card.dataset.name||'').toLowerCase();
    const location = (card.dataset.location||'').toLowerCase();

    if (price > maxPrice) return false;
    if (rating < minRating) return false;
    if (vOnly && !verified) return false;
    if (avail && card.dataset.availability !== avail) return false;
    if (qCat && card.dataset.category !== qCat) return false;

    if (tags.length){
      for (let t of tags){ if (!cardTags.includes(t)) return false; }
    }

    if (query){
      const hay = [name, location, category, cardTags].join(' ');
      if (!hay.includes(query)) return false;
    }

    if (chipVerified && !verified) return false;
    if (chipToday && cardAvail!=='today') return false;
    if (chipUnder500 && price>=500) return false;
    if (chipRating4 && rating<4) return false;

    return true;
  });

  // sort
  const val = sortSel.value;
  if (val==='priceAsc') filtered.sort((a,b)=> (+a.dataset.price) - (+b.dataset.price));
  if (val==='priceDesc') filtered.sort((a,b)=> (+b.dataset.price) - (+a.dataset.price));
  if (val==='ratingDesc') filtered.sort((a,b)=> (+b.dataset.rating) - (+a.dataset.rating));

  // apply visibility (pagination)
  applyVisibility(filtered);

  // empty state if none visible
  if (filtered.length===0){
    cardsWrap.innerHTML = `<div class="empty">No results. Try changing filters.</div>`;
    loadMoreBtn.style.display='none';
  }
}

// Events
[priceRange, ratingRange, verifiedOnly, availabilitySel, sortSel].forEach(el=> el.addEventListener('input', ()=>{
  priceVal.textContent = priceRange.value; ratingVal.textContent = ratingRange.value; visibleCount=6; filterAll();
}));
tagInput.addEventListener('input', ()=>{ visibleCount=6; filterAll(); });
chips.addEventListener('click', (e)=>{ if(e.target.classList.contains('chip')){ e.target.classList.toggle('active'); visibleCount=6; filterAll(); }});
qBtn.addEventListener('click', ()=>{ visibleCount=6; filterAll(); });

// Initial mount
priceVal.textContent = priceRange.value; ratingVal.textContent = ratingRange.value;
// first filter pass
filterAll();
</script>
</body>
</html>

<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

// Allow via email links (no session) for approve/reject only,
// but protect verify/unverify behind admin session.
$action = $_GET['action'] ?? '';
$id = (int)($_GET['id'] ?? 0);
if (!$id) die('Invalid id');

if (in_array($action,['approve','reject'])) {
  if ($action==='approve') {
    $stmt = db()->prepare("UPDATE providers SET status='approved' WHERE id=:id");
    $stmt->execute([':id'=>$id]);
  } else {
    $stmt = db()->prepare("UPDATE providers SET status='rejected' WHERE id=:id");
    $stmt->execute([':id'=>$id]);
  }
  echo "<body style='background:#0f1115;color:#dbeafe;font-family:Inter;padding:40px'>
  <h2>Provider #$id ".htmlspecialchars($action)."d</h2>
  <p><a style='color:#22ccff' href='".url('admin/dashboard.php')."'>Go to Dashboard</a></p></body>";
  exit;
}

// Remaining actions need admin
admin_require();
if ($action==='verify') {
  db()->prepare("UPDATE providers SET verified=1 WHERE id=:id")->execute([':id'=>$id]);
} elseif ($action==='unverify') {
  db()->prepare("UPDATE providers SET verified=0 WHERE id=:id")->execute([':id'=>$id]);
}
header('Location: '.url('admin/dashboard.php'));

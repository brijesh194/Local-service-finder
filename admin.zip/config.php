<?php
// ======= Global Config =======
define('DB_HOST', 'localhost');
define('DB_NAME', 'my_service_app');     // change as needed
define('DB_USER', 'root');
define('DB_PASS', '');                   // set password if any

// Absolute base URL of your project (no trailing slash)
define('BASE_URL', 'http://localhost/your-project-root');

// Admin email to receive verification requests
define('ADMIN_EMAIL', 'b8346145@gmail.com');

// Admin panel demo credentials (change in production)
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin123');

// UI config
define('SITE_NAME', 'LocalPro');

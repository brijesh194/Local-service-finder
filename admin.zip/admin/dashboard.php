<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';
admin_require();

// fetch pending + approved
$pending = db()->query("SELECT * FROM providers WHERE status='pending' ORDER BY created_at DESC")->fetchAll();
$approved = db()->query("SELECT * FROM providers WHERE status='approved' ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Admin Dashboard</title>
<style>
body{background:#0f1115;color:#e6f1ff;font-family:Inter,Arial}
.wrap{max-width:1100px;margin:24px auto;padding:0 16px}
.card{background:#121722;border:1px solid #1e2633;border-radius:16px;padding:16px;margin-bottom:16px}
.btn{background:#22ccff;border:none;padding:8px 12px;border-radius:10px;cursor:pointer}
.btn.red{background:#ef4444}
.table{width:100%;border-collapse:collapse}
.table th,.table td{border-bottom:1px solid #1e2633;padding:10px;text-align:left}
a{color:#dbeafe}
</style></head>
<body>
<div class="wrap">
  <h2>Admin Dashboard</h2>
  <div class="card">
    <h3>Pending Providers (<?= count($pending) ?>)</h3>
    <table class="table">
      <tr><th>Name</th><th>Service</th><th>Location</th><th>Price</th><th>ID</th><th>Actions</th></tr>
      <?php foreach($pending as $p): ?>
      <tr>
        <td><?= sanitize($p['name']) ?></td>
        <td><?= sanitize($p['service']) ?></td>
        <td><?= sanitize($p['location']) ?></td>
        <td>₹<?= (int)$p['price'] ?></td>
        <td><a href="<?= url($p['id_doc_path']) ?>" target="_blank">View ID</a></td>
        <td>
          <a class="btn" href="<?= url('admin/action.php?action=approve&id='.$p['id']) ?>">Approve</a>
          <a class="btn red" href="<?= url('admin/action.php?action=reject&id='.$p['id']) ?>">Reject</a>
        </td>
      </tr>
      <?php endforeach; if(empty($pending)) echo '<tr><td colspan="6">No pending providers.</td></tr>'; ?>
    </table>
  </div>

  <div class="card">
    <h3>Approved Providers (<?= count($approved) ?>)</h3>
    <table class="table">
      <tr><th>Name</th><th>Service</th><th>Verified</th><th>Actions</th></tr>
      <?php foreach($approved as $p): ?>
      <tr>
        <td><a href="<?= url('provider.php?id='.$p['id']) ?>" target="_blank"><?= sanitize($p['name']) ?></a></td>
        <td><?= sanitize($p['service']) ?></td>
        <td><?= $p['verified'] ? 'Yes' : 'No' ?></td>
        <td>
          <?php if($p['verified']==0): ?>
            <a class="btn" href="<?= url('admin/action.php?action=verify&id='.$p['id']) ?>">Mark Verified</a>
          <?php else: ?>
            <a class="btn red" href="<?= url('admin/action.php?action=unverify&id='.$p['id']) ?>">Remove Tick</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; if(empty($approved)) echo '<tr><td colspan="4">No approved providers.</td></tr>'; ?>
    </table>
  </div>
</div>
</body></html>

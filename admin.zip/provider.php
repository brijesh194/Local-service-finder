<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

// $id = (int)($_GET['id'] ?? 0);
// $stmt = db()->prepare("SELECT * FROM providers WHERE id=:id AND status='approved'");
// $stmt->execute([':id'=>$id]);
// $p = $stmt->fetch();
// if (!$p) { http_response_code(404); die('Provider not found or not approved'); }

// Fetch provider by ID without status check

$id = (int)($_GET['id'] ?? 0);

// Prepare query without status check
$stmt = db()->prepare("SELECT * FROM providers WHERE id=:id");
$stmt->execute([':id' => $id]);
$p = $stmt->fetch();

if (!$p) {
    http_response_code(404);
    die('Provider not found');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= sanitize($p['name']) ?> — <?= SITE_NAME ?></title>
<style>
body{margin:0;background:#0f1115;color:#e6f1ff;font-family:Inter,Arial}
.wrap{max-width:1100px;margin:0 auto;padding:20px}
.header{display:flex;gap:16px;align-items:center;margin:16px 0}
.photo{width:120px;height:120px;border-radius:16px;overflow:hidden;border:1px solid #1e2633}
.photo img{width:100%;height:100%;object-fit:cover}
.badge{background:#0ea5e9;color:#e6faff;border-radius:999px;padding:6px 10px;margin-left:8px}
.meta{color:#a5b4fc}
.card{background:#121722;border:1px solid #1e2633;border-radius:16px;padding:16px;margin:25px 0; padding-right: 50px;}
.btn{background:#22ccff;border:none;padding:12px 16px;border-radius:12px;font-weight:700;cursor:pointer}
input,textarea{width:100%;padding:12px;border-radius:12px;border:1px solid #243043;background:#0f131b;color:#dbeafe;margin:8px 0}
.row{display:grid;grid-template-columns:1fr 1fr;gap:50px}
</style>
</head>
<body>
<div class="wrap">
  <a href="s.php" style="color:#22ccff">&larr; Back</a>

  <div class="header">
    <div class="photo"><img src="/<?= htmlspecialchars($p['photo_path']) ?>" alt="<?= htmlspecialchars($p['name']) ?>"></div>
    <div>
      <h2 style="margin:6px 0">
        <?= sanitize($p['name']) ?>
        <?php if ($p['verified']): ?><span class="badge">✔ Verified</span><?php endif; ?>
      </h2>
      <div class="meta"><?= sanitize($p['service']) ?> • <?= sanitize($p['location']) ?> • <?= (int)$p['experience_years'] ?> yrs exp</div>
      <div class="meta">From ₹<?= (int)$p['price'] ?> • Rating <?= number_format((float)$p['rating'],1) ?>★</div>
    </div>
  </div>

  <div class="card">
    <h3>About</h3>
    <p><?= nl2br(sanitize($p['long_desc'] ?: $p['short_desc'])) ?></p>
    <p class="meta">Tags: <?= sanitize($p['tags']) ?> | Availability: <?= sanitize($p['availability']) ?></p>
  </div>

  <div class="card" id="book">
    <h3>Book / Contact</h3>
    <form action="book.php" method="post">
      <input type="hidden" name="provider_id" value="<?= $p['id'] ?>">
      <div class="row">
        <div><label>Your Name</label><input name="customer_name" required></div>
        <div><label>Your Email</label><input type="email" name="customer_email" required></div>
      </div>
      <div class="row">
        <div><label>Your Phone</label><input name="customer_phone" required></div>
        <div><label>Preferred Time</label><input name="preferred_time" placeholder="e.g., Today 5 PM"></div>
      </div>
      <label>Message</label>
      <textarea name="message" rows="4" placeholder="Describe the job"></textarea>
      <button class="btn" style="margin-top:10px">Send Request</button>
    </form>
    <p class="meta" style="margin-top:8px">Or contact directly: <?= sanitize($p['contact_email']) ?> • <?= sanitize($p['contact_phone']) ?></p>
  </div>
</div>
</body>
</html>
